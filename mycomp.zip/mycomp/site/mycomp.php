<?php
defined('_JEXEC') or die("Acess deny");

echo "<h3>Welcome to front end</h3>";



 ?>